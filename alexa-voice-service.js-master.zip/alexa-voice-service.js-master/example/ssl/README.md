Self-signed SSL Certficates

See this [blog post](https://miguelmota.com/blog/generate-self-signed-ssl-certificate/) on how to generate your own.
